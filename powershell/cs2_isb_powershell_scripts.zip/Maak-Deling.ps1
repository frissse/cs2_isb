﻿# Maak-Deling2.ps1
# Default waarde van deeltal en deler is 1
Param(
[int]$deeltal=1,
[int]$deler=1
)
Write-Host ($deeltal / $deler)