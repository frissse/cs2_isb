﻿cat ~/my_password.txt | docker login --username frissse@proton.me --password-stdin

docker run -d -p 80:80 emptier1359/iis-site-windows